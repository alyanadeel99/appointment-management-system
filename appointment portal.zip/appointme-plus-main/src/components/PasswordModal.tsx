import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";

interface PasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  role: "doctor" | "admin";
}

const PASSWORDS = {
  doctor: "doctor123",
  admin: "admin123",
};

export const PasswordModal = ({ isOpen, onClose, onSuccess, role }: PasswordModalProps) => {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === PASSWORDS[role]) {
      onSuccess();
      setPassword("");
      setError("");
    } else {
      setError("Oops! Wrong password. Please try again.");
      setPassword("");
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <Lock className="h-8 w-8 text-primary" />
          </div>
          <DialogTitle className="text-center text-2xl">
            {role === "doctor" ? "Doctor" : "Admin"} Access
          </DialogTitle>
          <DialogDescription className="text-center">
            Please enter your password to continue
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Input
              type="password"
              placeholder="Enter password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError("");
              }}
              className="text-center"
              autoFocus
            />
            {error && (
              <p className="text-sm text-destructive text-center animate-in fade-in">
                {error}
              </p>
            )}
          </div>
          <div className="flex gap-3">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1 btn-glow">
              Enter
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
