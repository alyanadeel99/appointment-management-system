import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface RoleCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  onClick: () => void;
  gradient: string;
}

export const RoleCard = ({ icon: Icon, title, description, onClick, gradient }: RoleCardProps) => {
  return (
    <Card 
      className="card-hover cursor-pointer border-2 transition-all hover:border-primary/50"
      onClick={onClick}
    >
      <CardContent className="p-8 text-center">
        <div 
          className={`mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl ${gradient}`}
        >
          <Icon className="h-10 w-10 text-white" />
        </div>
        <h3 className="mb-3 text-2xl font-bold">{title}</h3>
        <p className="text-muted-foreground leading-relaxed">{description}</p>
      </CardContent>
    </Card>
  );
};
