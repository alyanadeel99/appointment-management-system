import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Calendar, Clock, User, ArrowLeft, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const PatientDashboard = () => {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // For demo purposes, we'll show mock appointments
    // In production, this would fetch from the database using auth
    const mockAppointments = [
      {
        id: "1",
        doctor_name: "Dr. Ayesha Khan",
        specialization: "Pediatrician",
        date: "2025-10-30",
        time: "10:00 AM",
        status: "scheduled"
      },
      {
        id: "2",
        doctor_name: "Dr. Hamza Rehman",
        specialization: "Dermatologist",
        date: "2025-11-01",
        time: "12:30 PM",
        status: "scheduled"
      }
    ];
    setAppointments(mockAppointments);
    setLoading(false);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => navigate("/")}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <User className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium">Patient Portal</p>
                <p className="text-xs text-muted-foreground">Ali Raza</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">My Appointments</h1>
            <p className="text-muted-foreground">View and manage your healthcare appointments</p>
          </div>
          <Button className="gap-2 btn-glow" onClick={() => navigate("/patient/book")}>
            <Plus className="h-4 w-4" />
            Book Appointment
          </Button>
        </div>

        {/* Appointments Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {loading ? (
            <p className="text-muted-foreground">Loading appointments...</p>
          ) : appointments.length === 0 ? (
            <Card className="col-span-full">
              <CardContent className="py-12 text-center">
                <Calendar className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="mb-2 text-lg font-semibold">No appointments yet</h3>
                <p className="text-muted-foreground mb-4">Book your first appointment to get started</p>
                <Button onClick={() => navigate("/patient/book")}>Book Now</Button>
              </CardContent>
            </Card>
          ) : (
            appointments.map((appointment) => (
              <Card key={appointment.id} className="card-hover">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-xl">
                    {appointment.doctor_name}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">{appointment.specialization}</p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-primary" />
                    <span>{new Date(appointment.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-secondary" />
                    <span>{appointment.time}</span>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" className="flex-1" size="sm">
                      Reschedule
                    </Button>
                    <Button variant="destructive" className="flex-1" size="sm">
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
};

export default PatientDashboard;
