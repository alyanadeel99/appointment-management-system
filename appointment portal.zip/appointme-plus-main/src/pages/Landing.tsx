import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, Stethoscope, Settings } from "lucide-react";
import { RoleCard } from "@/components/RoleCard";
import { PasswordModal } from "@/components/PasswordModal";

const Landing = () => {
  const navigate = useNavigate();
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [selectedRole, setSelectedRole] = useState<"doctor" | "admin" | null>(null);

  const handleRoleClick = (role: "patient" | "doctor" | "admin") => {
    if (role === "patient") {
      navigate("/patient");
    } else {
      setSelectedRole(role);
      setShowPasswordModal(true);
    }
  };

  const handlePasswordSuccess = () => {
    setShowPasswordModal(false);
    if (selectedRole === "doctor") {
      navigate("/doctor");
    } else if (selectedRole === "admin") {
      navigate("/admin");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/5">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-secondary">
              <Stethoscope className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gradient">CareConnect</h1>
              <p className="text-sm text-muted-foreground">Making healthcare simple, one appointment at a time</p>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-4 py-16">
        <div className="mx-auto max-w-4xl text-center mb-16 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <h2 className="mb-4 text-5xl font-bold leading-tight">
            Welcome to <span className="text-gradient">CareConnect</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Your smart way to manage clinic appointments
          </p>
          <p className="text-lg text-muted-foreground">
            Please select your role to continue
          </p>
        </div>

        {/* Role Selection Cards */}
        <div className="mx-auto max-w-6xl grid gap-8 md:grid-cols-3 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
          <RoleCard
            icon={User}
            title="Patient"
            description="Book, reschedule, or cancel appointments with ease"
            onClick={() => handleRoleClick("patient")}
            gradient="bg-gradient-to-br from-primary to-primary-glow"
          />
          <RoleCard
            icon={Stethoscope}
            title="Doctor"
            description="Manage availability, view upcoming consultations"
            onClick={() => handleRoleClick("doctor")}
            gradient="bg-gradient-to-br from-secondary to-green-400"
          />
          <RoleCard
            icon={Settings}
            title="Admin"
            description="Oversee clinic operations, billing, and reports"
            onClick={() => handleRoleClick("admin")}
            gradient="bg-gradient-to-br from-accent to-orange-400"
          />
        </div>

        {/* Footer Note */}
        <div className="mt-16 text-center">
          <p className="text-sm text-muted-foreground">
            New to CareConnect? Start as a <span className="font-semibold text-primary">Patient</span> to explore
          </p>
        </div>
      </main>

      {/* Password Modal */}
      {selectedRole && (
        <PasswordModal
          isOpen={showPasswordModal}
          onClose={() => {
            setShowPasswordModal(false);
            setSelectedRole(null);
          }}
          onSuccess={handlePasswordSuccess}
          role={selectedRole}
        />
      )}
    </div>
  );
};

export default Landing;
